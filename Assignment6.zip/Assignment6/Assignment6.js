﻿let slideNum=1;
let slideNext=2;

count=$("#slider > img").length;
$(document).ready(function(){
	$("#slider>img#1").fadeIn(300);
	startSlider();
});

$("#upload").click(function(){
	let name = $("#images").val().substring(11,$("#images").val().length);
	$("#slider").prepend('<img id="'+0+'" src="'+'\images'+`${name}`+'"></img>');

	$("img").each(function(){
		this.id++;
	});
	count=$("#slider > img").length;
	window.clearInterval(loop);
	$("#slider > img").fadeOut(300);
	$("#slider > img#1").fadeIn(300);
	slideNum=1;
	slideNext=2;
	startSlider();

});

	
$("#images").change(function(){
	if(typeof(FileReader)!="undefined"){
		var preview_image = $("#preview");
		preview_image.empty();

		var reader = new FileReader();
		reader.onload = function(e){
			$("<img />",{
				"src":e.target.result,
				"class":"thumb_image"
			}).appendTo(preview_image);
		}
		preview_image.show();
		reader.readAsDataURL($(this)[0].files[0]);
	}else{
		alert("This browser does not support FileReader");
	}
});
function startSlider(){
	
	loop=setInterval(function(){
		if(slideNext> count){
			slideNext = 1;
			slideNum = 1;
		}

		$("#slider > img").fadeOut(300);
		$("#slider > img#"+slideNext).fadeIn(300);

		slideNum = slideNext;
		slideNext = slideNext+1;
	},2000)
}
$(".see_previous").click(function(){
	newSlide=slideNum-1;
	showSlide(newSlide);
	
});
$(".see_next").click(function(){
	newSlide=slideNum+1;
	showSlide(newSlide);
	
});
function showSlide(Id){
	window.clearInterval(loop);
	if(Id > count){
		Id=1;
	}
	else if(Id < 1){
		Id = count;
	}
	$("#slider > img").fadeOut(300);
	$("#slider > img#"+Id).fadeIn(300);

	slideNum=Id;
	slideNext=Id+1;
}
$("h4").click(function(){
	startSlider();
});